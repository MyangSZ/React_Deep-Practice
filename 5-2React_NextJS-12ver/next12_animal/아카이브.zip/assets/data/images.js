import cat from '../images/cat.png'
import cow from '../images/cow.png'
import dog from '../images/dog.png'
import duck from '../images/duck.png'
import fox from '../images/fox.png'
import frog from '../images/frog.png'
import giraffe from '../images/giraffe.png'
import lion from '../images/lion.png'
import panda from '../images/panda.png'
import penguin from '../images/penguin.png'
import pig from '../images/pig.png'
import rabbit from '../images/rabbit.png'
import sheep from '../images/sheep.png'
import tiger from '../images/tiger.png'

export default {
    cat, cow, dog, duck, fox, frog, giraffe, lion, panda, penguin, pig, rabbit, sheep, tiger
}